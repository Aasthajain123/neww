


package com.code.controller;

        import java.util.List;

  import org.springframework.beans.factory.annotation.Autowired;
  import org.springframework.beans.factory.annotation.Value;
  import org.springframework.stereotype.Component;
  import org.springframework.web.bind.annotation.*;

  import com.code.entity.Course;
  import com.code.service.CourseService;
  @Component
@RestController
@RequestMapping(value= "/course")
public class CourseController {

    @Autowired CourseService courseService;

    @Value("${message:default message}")
    private String message;

    @GetMapping("/message")
    public String getMessage() {
        return message;
    }

    @PostMapping
    public boolean create(@RequestBody Course course) {
        return courseService.create(course);
    }

    @GetMapping
    public List<Course> getAll() {
        return courseService.getAll();
    }
    @GetMapping("/hello")
    public String hello(@RequestParam(value = "name", defaultValue = "World") String name) {
        return String.format("Hello %s!", name);
    }
    @GetMapping("/id")
    public Course getById(@RequestParam(value = "id", defaultValue = "1") int id) {
        return courseService.getById(id);
    }

    @PutMapping
    public boolean update(@RequestBody Course course) {
        return courseService.update(course);
    }

    @DeleteMapping
    public boolean delete(@RequestParam int id) {
        return courseService.delete(id);
    }
}
